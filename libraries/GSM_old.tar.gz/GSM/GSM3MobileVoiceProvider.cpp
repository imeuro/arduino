#include <GSM3MobileVoiceProvider.h>


GSM3MobileVoiceProvider* theGSM3MobileVoiceProvider;
