DS3231_weekday_accessible
=========================

Modified the original DS3231 library so that I could get weekday. e.g. now.dayOfWeek()
The original library: http://hacks.ayars.org/2011/04/ds3231-real-time-clock.html

Thanks to Dr.Ayars for the original code :)